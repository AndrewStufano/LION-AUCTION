import csv
import sqlite3 as sql
import hashlib

connection = sql.connect('liondatabase.db')
cursor = connection.execute('CREATE TABLE User_s(email TEXT PRIMARY KEY, password TEXT);')
with open ('User.csv', mode = 'r') as file:
        csvfile = csv.reader(file)
        for lines in csvfile:
            email = lines[0]
            password = lines[1]
            cursor = connection.execute('INSERT INTO User_s (email, password) VALUES (?,?);', (email,hashlib.sha256(password.encode('utf-8')).hexdigest()))
            connection.commit()






