
from flask import Flask, render_template,request,session,redirect
from flask_session import Session
import sqlite3 as sql
import os
import hashlib
app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_KEY"] = str(os.urandom(12))
Session(app)
host = 'http://127.0.0.1:5000/'

def valid_name(email, password):
    connection = sql.connect('liondatabase.db')
    hash_password = hashlib.sha256(password.encode('utf-8')).hexdigest()
    #cursor = connection.execute('SELECT password FROM User WHERE email =?;', (email, password))
    cursor = connection.execute('SELECT password FROM User_s WHERE email = ? AND password = ?;', (email, hash_password))
    #cursor = connection.execute('SELECT * FROM USERS ;')
    connection.commit()
    return cursor.fetchone()



@app.route('/', methods = ['GET','POST'])
def login():
    if request.method == 'POST':
        result = valid_name(request.form['email'],request.form['password'])
        if result:
            session["email"] = request.form["email"]
            return redirect('/profile')
        else:
            return "Unable to login, You are not registered"

    return render_template('login.html')

def bidder_info(email):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT B.email,B.first_name,B.last_name,B.gender,B.age,B.major FROM Bidders B ,User_s U WHERE B.email = U.email AND B.email= ?;',(email))
    connection.commit()
    return cursor.fetchone()

@app.route('/profile',methods = ['GET' ,'POST'])
def bidder_display():
    result = bidder_info([session["email"]])
    result2 = bidder_addr([session["email"]])
    result3 = bidder_card_info([session["email"]])
    if result:
        return render_template('Profile.html',result=[result],email = result,result2=[result2],result3=[result3])

    # return render_template('Profile.html',email = bidder_info([session["email"]]))

def bidder_addr(email):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT A.zipcode,A.street_num,A.street_name FROM Address A ,Bidders B WHERE A.address_ID = B.home_address AND B.email = ?;',(email))
    connection.commit()
    return cursor.fetchone()

@app.route('/profile',methods = ['GET' ,'POST'])
def bidder_card_info(email):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT C.credit_card_num,C.card_type,C.expire_month,C.expire_year,C.security_code FROM Credit_Cards C,Bidders B WHERE B.email = C.Owner_email AND B.email = ?;',(email))
    connection.commit()
    return cursor.fetchone()

@app.route('/profile2',methods = ['GET' ,'POST'])
def seller_display():
    result = seller_info([session["email"]])
    result2 = seller_listings([session["email"]])
    if result:
        return render_template('Seller.html', result=[result],result2= result2 ,email=result)
    return render_template('Seller.html', result=[result], result2= result2,email=result)

@app.route('/profile2',methods = ['GET' ,'POST'])
def seller_info(email):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT S.email,S.banking_routing_number,S.bank_account_number,S.balance FROM Sellers S ,User_s U WHERE U.email = S.email AND S.email = ?;',(email))
    connection.commit()
    return cursor.fetchone()

@app.route('/profile2', methods=['GET', 'POST'])
def seller_listings(email):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT Seller_Email,Listing_ID,Category,Auction_Title,Product_Name,Product_Description,Quantity,Reserve_Price,Max_bids,Status FROM Auction_Listings WHERE Seller_Email = ?;',(email))
    connection.commit()
    return cursor.fetchall()


@app.route('/profile3',methods = ['GET' ,'POST'])
def help_desk_display():
    result = help_desk_info([session["email"]])
    result2 = help_desk_requests([session["email"]])
    if result:
        return render_template('HelpDesk.html', result=[result],result2 = result2, email=result)

@app.route('/profile3',methods = ['GET' ,'POST'])
def help_desk_requests(email):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT request_id,sender_email,helpdesk_staff_email,request_type,request_desc,request_status FROM Requests WHERE helpdesk_staff_email = ?;',(email))
    connection.commit()
    return cursor.fetchall()
@app.route('/profile3',methods = ['GET' ,'POST'])
def help_desk_info(email):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT P.email, P.position FROM HelpDesk P, User_s S WHERE P.email = S.email and P.email = ?',(email))
    connection.commit()
    return cursor.fetchone()


@app.route('/category')
def category():
    return render_template('Category_Dynamic.html')


@app.route('/profile4',methods = ['GET' ,'POST'])
def local_seller_info(email):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT L.Business_Name, L.Customer_Service_Phone_Number FROM Local_Vendors L, Sellers S WHERE L.email = S.email AND L.email = ?;',(email))
    connection.commit()
    return cursor.fetchone()

@app.route('/profile4',methods = ['GET' ,'POST'])
def local_seller_display():
    result = local_seller_info([session["email"]])
    if result:
        return render_template('Local_Vendor.html', result=[result], email=result)
    else:
        return "You are not a Vendor"



@app.route('/electrical_supply',methods = ['GET' ,'POST'])
def electrical_supply_display():
    return render_template('Electrical_Supplies.html')


def select_category():
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT parent_category FROM Categories;')
    connection.commit()
    return cursor.fetchall()

def select_sub_category(parent_category):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT category_name FROM Categories WHERE parent_category = ?;',[parent_category])
    connection.commit()
    return cursor.fetchall()

@app.route('/CATSELECT',methods = ['GET' ,'POST'])
def select_category_display():
    result = select_category()
    if result:
        return render_template('Category_Dynamic.html',result= result)

@app.route('/CATSUBSELECT',methods = ['GET' ,'POST'])
def select_category_sub_display():
    result = select_sub_category(request.form['main'])
    if result:
        return render_template('Sub_Category.html',result= result,main= result)

def category_info_table(category):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT A.Seller_Email,A.Listing_ID,A.Category,A.Auction_Title,A.Product_Name,A.Product_Description,A.Quantity,A.Reserve_Price,A.Max_bids,A.Status FROM  Auction_Listings A ,Categories C WHERE A.Category = C.category_name AND A.Category = ?  ;',[category])
    connection.commit()
    return cursor.fetchall()

@app.route('/categorytable',methods = ['GET' ,'POST'])
def category_info_table_display():
        result = category_info_table(request.form['main'])
        if result:
            return render_template('Dynamic_Category_Display.html', result=result,main = result)


@app.route('/addauction', methods=['POST', 'GET'])
def add_auction():
    error = None
    if request.method == 'POST':
        result = valid_auction(request.form['SellerEmail'],request.form['ListingID'], request.form['Category'],request.form['AuctionTitle'],request.form['ProductName'],request.form['ProductDescription'],request.form['Quantity'],request.form['ReservePrice'],request.form['MaxBids'],request.form['Status'])
        if result:
            return render_template('add_auction.html', result=result,error =error)
        else:
            error = 'invalid input name'
    return render_template('add_auction.html', error=error)


def valid_auction(seller_email,listing_id,category,auction_title,product_name,product_description,quantity,reserve_price,max_bids,status):
    connection = sql.connect('liondatabase.db')
    connection.execute('INSERT INTO Auction_Listings (seller_email,listing_id,category,auction_title,product_name,product_description,quantity,reserve_price,max_bids,status) VALUES (?,?,?,?,?,?,?,?,?,?); ', (seller_email,listing_id,category,auction_title,product_name,product_description,quantity,reserve_price,max_bids,status))
    connection.commit()
    cursor = connection.execute('SELECT * FROM Auction_Listings;')
    return cursor.fetchall()


@app.route('/addcategory', methods=['POST', 'GET'])
def add_category():
    error = None
    if request.method == 'POST':
        result = valid_category(request.form['Parent'],request.form['Category'])
        if result:
            return render_template('add_category.html', result=result,error =error)
        else:
            error = 'invalid input name'
    return render_template('add_category.html', error=error)


def valid_category(parent_category,category_name):
    connection = sql.connect('liondatabase.db')
    connection.execute('INSERT INTO Categories (parent_category,category_name) VALUES (?,?); ',(parent_category,category_name))
    connection.commit()
    cursor = connection.execute('SELECT * FROM Categories;')
    return cursor.fetchall()

@app.route('/request', methods=['POST', 'GET'])
def request_add():
    error = None
    if request.method == 'POST':
        result = valid_request(request.form['RequestID'],request.form['SenderEmail'], request.form['HelpID'],request.form['RequestType'],request.form['RequestDescription'],request.form['Requeststatus'])
        if result:
            return render_template('Request.html', result=result,error =error)
        else:
            error = 'invalid input name'
    return render_template('Request.html', error=error)

def valid_request(request_id,sender_email,helpdesk_staff_email,request_type,request_desc,request_status):
    connection = sql.connect('liondatabase.db')
    connection.execute('INSERT INTO Requests (request_id,sender_email,helpdesk_staff_email,request_type,request_desc,request_status) VALUES (?,?,?,?,?,?); ', (request_id,sender_email,helpdesk_staff_email,request_type,request_desc,request_status))
    connection.commit()
    cursor = connection.execute('SELECT * FROM Requests;')
    return cursor.fetchall()

@app.route('/auctiondelete', methods=['POST', 'GET'])
def auction_delete():
    error = None
    if request.method == 'POST':
        result = valid_delete(request.form['ListingID'])
        return render_template('delete_auction.html', result=result, error=error)
    else:
        error = 'invalid input '
    return render_template('delete_auction.html', error=error)

def valid_delete(listing_id):
    connection = sql.connect('liondatabase.db')
    connection.execute('DELETE FROM Auction_Listings WHERE Listing_ID = ?;',(listing_id,))
    connection.commit()
    cursor = connection.execute('SELECT * FROM Auction_Listings;')
    return cursor.fetchall()


def place_bid(bid_id,seller_email,listing_id,bidder_email,bid_price):
    connection = sql.connect('liondatabase.db')
    connection.execute('INSERT INTO Bids (bid_id,seller_email,listing_id,bidder_email,bid_price) VALUES (?,?,?,?,?); ', (bid_id,seller_email,listing_id,bidder_email,bid_price))
    connection.commit()
    cursor = connection.execute('SELECT * FROM Bids;')
    return cursor.fetchall()

@app.route('/placebid', methods=['POST', 'GET'])
def place_bid_display():
    error = None
    if request.method == 'POST':
        result = place_bid(request.form['BidID'],request.form['SellerEmail'],request.form['ListingID'],request.form['BidEmail'],request.form['BidPrice'])
        return render_template("Auction.Bidding.html",result = result,error=error)
    else:
        error = 'invalid input '
    return render_template('Auction.Bidding.html', error=error)

def new_user_info(email,password):
    connection = sql.connect('liondatabase.db')
    connection.execute('INSERT INTO User_s (email, password) VALUES (?,?);',(email, hashlib.sha256(password.encode('utf-8')).hexdigest()))
    connection.commit()
    cursor = connection.execute('SELECT * FROM User_s;')
    return cursor.fetchall()


@app.route('/newuser', methods=['GET', 'POST'])
def new_user():
    error = None
    if request.method == 'POST':
        result = new_user_info(request.form['Email'], request.form['Password'])
        return render_template("New_User.html", result=result, error=error)
    else:
        error = 'invalid input '
    return render_template('New_User.html', error=error)



@app.route('/payment', methods=['GET', 'POST'])
def confirm_card():
    result3 = bidder_card_info([session["email"]])
    if result3:
        return render_template('CreditCardInfo.html', result3=[result3])



def card_info(email):
    connection = sql.connect('liondatabase.db')
    cursor = connection.execute('SELECT C.credit_card_num,C.card_type,C.expire_month,C.expire_year,C.security_code FROM Credit_Cards C,Bidders B WHERE B.email = C.Owner_email AND B.email = ?;',(email))
    connection.commit()
    return cursor.fetchone()






# @app.route('/wearabletech',methods = ['GET' ,'POST'])
# def Wearable_Tech_Display():
#     return render_template('Wearable_Tech.html')
#
# @app.route('/CellPhones',methods = ['GET' ,'POST'])
# def IPHONE_DISPLAY():
#     return render_template('Cell_Phone.html')
#
# @app.route('/grocery',methods = ['GET' ,'POST'])
# def Groccery_DISPLAY():
#     return render_template('Grocery.html')
#
# @app.route('/kitchen',methods = ['GET' ,'POST'])
# def Kitchen_DISPLAY():
#     return render_template('Kitchen & Applicances.html')
#
# @app.route('/kitchenandcooking',methods = ['GET' ,'POST'])
# def Kitchen_Cooking_DISPLAY():
#     return render_template('Kitchen_Cooking.html')
#
# @app.route('/cabs',methods = ['GET' ,'POST'])
# def cabients_DISPLAY():
#     return render_template('Kitchen_Cabinets.html')
#
# @app.route('/faucetsandsinks',methods = ['GET' ,'POST'])
# def faucets_sink_DISPLAY():
#     return render_template('Faucents_Sinks.html')
#
#
# @app.route('//patioandgarden',methods = ['GET' ,'POST'])
# def Patio_Garden():
#     return render_template('Patio_Garden.html')
#
# @app.route('/furniture',methods = ['GET' ,'POST'])
# def Patio_Furniture():
#     return render_template('Patio_Furniture.html')
#
# @app.route('/decor',methods = ['GET' ,'POST'])
# def Patio_Decor():
#     return render_template('Outdoor_Decor.html')
#
# @app.route('/IndoorPlants',methods = ['GET' ,'POST'])
# def indoor_plant_display():
#     return render_template('Indoor_Live_Plants.html')
#
# @app.route('/OutdoorPlants',methods = ['GET' ,'POST'])
# def outdoor_plant_display():
#     return render_template('Outdoor_Plants.html')
#
# @app.route('/PlantGifts',methods = ['GET' ,'POST'])
# def plant_gift_display():
#     return render_template('Plant_Gift.html')
#
# @app.route('/annual',methods = ['GET' ,'POST'])
# def annual_display():
#     return render_template('Annuals.html')
#
# @app.route('/sportsandoutdoors',methods = ['GET' ,'POST'])
# def sports_outdoors_display():
#     return render_template('Sports.html')
#
# @app.route('/Sports',methods = ['GET' ,'POST'])
# def sports_display():
#     return render_template('Sports_Page.html')
#
# @app.route('/Baseball',methods = ['GET' ,'POST'])
# def baseball_display():
#     return render_template('Baseball.html')
#
# @app.route('/Basketball',methods = ['GET' ,'POST'])
# def basketball_display():
#     return render_template('Basketball.html')
#
#
# @app.route('/exercise&fit',methods = ['GET' ,'POST'])
# def exercise_fit_display():
#     return render_template('exercise&fit.html')
#
# @app.route('/machines',methods = ['GET' ,'POST'])
# def machine_display():
#     return render_template('Machines.html')
#
# @app.route('/yoga',methods = ['GET' ,'POST'])
# def yoga_display():
#     return render_template('Yoga.html')
#
# @app.route('/Bikes',methods = ['GET' ,'POST'])
# def bikes_display():
#     return render_template('Bikes.html')
#
# @app.route('/boxing',methods = ['GET' ,'POST'])
# def boxing_display():
#     return render_template('Boxing.html')
#
# @app.route('/meat&food',methods = ['GET' ,'POST'])
# def meat_food_display():
#     return render_template('Meat&food.html')
#
# @app.route('/freshproduce',methods = ['GET' ,'POST'])
# def produce_display():
#     return render_template('Fresh_Produce.html')
#
# @app.route('/clothing',methods = ['GET' ,'POST'])
# def clothing_display():
#     return render_template('Clothing.html')
#
# @app.route('/bakerybread',methods = ['GET' ,'POST'])
# def bakery_bread_display():
#     return render_template('Bakery&Bread.html')
#
# @app.route('/sleepwear',methods = ['GET' ,'POST'])
# def sleep_wear_display():
#     return render_template('sleepwear.html')
#
# @app.route('/tops',methods = ['GET' ,'POST'])
# def top_display():
#     return render_template('tops.html')
#
# @app.route('/bottoms',methods = ['GET' ,'POST'])
# def bottom_display():
#     return render_template('Bottoms.html')
#
# @app.route('/beautyproducts',methods = ['GET' ,'POST'])
# def beauty_display():
#     return render_template('Makeup.html')
#
# @app.route('/makeup',methods = ['GET' ,'POST'])
# def type_make_up_display():
#     return render_template('Types of makeup.html')
#
# @app.route('/face',methods = ['GET' ,'POST'])
# def face_display():
#     return render_template('Face.html')
#
# @app.route('/lip',methods = ['GET' ,'POST'])
# def lip_display():
#     return render_template('Lip.html')
#
# @app.route('/brushes',methods = ['GET' ,'POST'])
# def brushes_display():
#     return render_template('Face.html')
#
# @app.route('/pharm',methods = ['GET' ,'POST'])
# def pharm_display():
#     return render_template('HealthCare.html')
#
# @app.route('/pain',methods = ['GET' ,'POST'])
# def pain_display():
#     return render_template('Pain_Relievers.html')
#
# @app.route('/eyecare',methods = ['GET' ,'POST'])
# def eye_display():
#     return render_template('EyeCare.html')
#
# @app.route('/coldflu',methods = ['GET' ,'POST'])
# def cold_flu_display():
#     return render_template('Cold&Flu.html')
#
# @app.route('/pets',methods = ['GET' ,'POST'])
# def pet_display():
#     return render_template('Animals_Page.html')
#
# @app.route('/cats',methods = ['GET' ,'POST'])
# def cats_display():
#     return render_template('Cats.html')
#
# @app.route('/dogs',methods = ['GET' ,'POST'])
# def dogs_display():
#     return render_template('Dogs.html')
#
# @app.route('/toygames',methods = ['GET' ,'POST'])
# def toys_games_display():
#     return render_template('ToysGames.html')
#
# @app.route('/outplay',methods = ['GET' ,'POST'])
# def out_door_play_display():
#     return render_template('OutdoorPlay.html')
#
# @app.route('/toys',methods = ['GET' ,'POST'])
# def toys_display():
#     return render_template('Toys.html')
#
# @app.route('/videogames',methods = ['GET' ,'POST'])
# def video_game_display():
#     return render_template('Video_Games.html')
#
# @app.route('/deleteauction',methods = ['GET' ,'POST'])
# def delete_auction_display():
#     return render_template('delete_auction.html')
#
# @app.route('/addauction',methods = ['GET' ,'POST'])
# def add_auctiondisplay():
#     return render_template('add_auction.html')



if __name__ == '__main__':
    app.run(debug=True)
